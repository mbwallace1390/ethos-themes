# RF Lime Pro v1.2.2

Requires ETHOS 26.1.0 or newer; API checked against 26.1.2. Radio validation is still required.

Install the ZIP with ETHOS Suite's local ZIP installer. For manual ZIP installation, create `scripts/theme-rf-lime-pro/` on the transmitter and extract the ZIP contents into that folder.

A lightweight FrSky ETHOS theme based on the proven RF Blue Pro design.

- Bright lime outline focus
- Dark square controls
- Clear active, inactive, and disabled states
- Responsive 784x50 X20 / 464x50 X18 toolbar
- ETHOS-safe internal key `RFLime`
- Installs beside every other RF Pro theme
- Palette-matched ETHOS header logo with a transparent background
- Artwork is drawn on either side of a clear logo area at both native widths

To install from repository sources, copy the complete `theme-rf-lime-pro` folder into the transmitter's `scripts` folder, restart, and select **RF Lime Pro** under **System > General > Theme**.

`main.luac` is intentionally omitted so ETHOS creates a fresh compiled copy.
