# Aviation HUD v1.1.0

Requires ETHOS 26.1.0 or newer; API checked against 26.1.2. Radio validation is still required.

Install the ZIP with ETHOS Suite's local ZIP installer. For manual ZIP installation, create `scripts/theme-aviation-hud/` on the transmitter and extract the ZIP contents into that folder.

**Collection:** Flight Systems

A standalone FrSky ETHOS radio theme with custom toolbar artwork.

- Focus: `outline`
- Controls: square
- Internal key: `AvHUD`
- Responsive 784x50 X20 / 464x50 X18 toolbar
- Does not modify Rotorflight or RF Suite Lua files

To install from repository sources, copy `theme-aviation-hud` into the transmitter `scripts` folder, restart, then select **Aviation HUD** under **System > General > Theme**.
