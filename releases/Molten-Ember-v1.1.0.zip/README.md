# Molten Ember v1.1.0

Requires ETHOS 26.1.0 or newer; API checked against 26.1.2. Radio validation is still required.

Install the ZIP with ETHOS Suite's local ZIP installer. For manual ZIP installation, create `scripts/theme-molten-ember/` on the transmitter and extract the ZIP contents into that folder.

**Family:** Molten

A standalone FrSky ETHOS theme.

- Focus: `outline`
- Controls: square
- Internal key: `MltEmbr`
- Automatically selects 784x50 artwork on 800px radios and 464x50 artwork on standard X18 radios

To install from repository sources, copy `theme-molten-ember` into the transmitter `scripts` folder, restart, and select **Molten Ember** under **System > General > Theme**.
