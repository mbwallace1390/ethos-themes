# RF Lime Pro v1.0.0

A lightweight FrSky ETHOS theme based on the proven RF Blue Pro design.

- Bright lime outline focus
- Dark square controls
- Clear active, inactive, and disabled states
- Lightweight 784x50 toolbar
- ETHOS-safe internal key `RFLime`
- Installs beside every other RF Pro theme

Copy the complete `theme-rf-lime-pro` folder into the transmitter's `scripts` folder, restart, and select **RF Lime Pro** under **System > General > Theme**.

`main.luac` is intentionally omitted so ETHOS creates a fresh compiled copy.
