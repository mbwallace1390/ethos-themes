# Soft Coral v1.2.2

Requires ETHOS 26.1.0 or newer; API checked against 26.1.2. Radio validation is still required.

Install the ZIP with ETHOS Suite's local ZIP installer. For manual ZIP installation, create `scripts/theme-soft-coral/` on the transmitter and extract the ZIP contents into that folder.

**Family:** Soft

A lightweight standalone FrSky ETHOS theme.

- Focus: `invert`
- Controls: rounded
- Internal key: `SCoral`
- Responsive 784x50 X20 / 464x50 X18 toolbar
- Palette-matched ETHOS header logo with a transparent background
- Artwork is drawn on either side of a clear logo area at both native widths

To install from repository sources, copy `theme-soft-coral` into the transmitter `scripts` folder, restart, and select **Soft Coral**.
