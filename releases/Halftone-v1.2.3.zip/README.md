# Halftone v1.2.3

Requires ETHOS 26.1.0 or newer; API checked against 26.1.2. Radio validation is still required.

Install the ZIP with ETHOS Suite's local ZIP installer. For manual ZIP installation, create `scripts/theme-halftone/` on the transmitter and extract the ZIP contents into that folder.

**Collection:** Texture

A standalone FrSky ETHOS theme.

- Focus: `outline`
- Controls: square
- Internal key: `Halftn`
- Automatically selects 784x50 artwork on 800px radios and 464x50 artwork on standard X18 radios
- Does not modify Rotorflight or RF Suite Lua files
- Palette-matched ETHOS header logo with a transparent background
- Continuous toolbar styling with prominent artwork arranged around the lettering at both native widths

To install from repository sources, copy `theme-halftone` into the transmitter `scripts` folder, restart, and select **Halftone** under **System > General > Theme**.
