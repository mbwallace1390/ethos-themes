-- Summit
-- Standalone ETHOS radio theme. Rotorflight and RF Suite files are not modified.
local function selectToolbar(largeFile, smallFile)
    local version = system.getVersion()
    if version and version.lcdWidth and version.lcdWidth <= 480 then
        return smallFile
    end
    return largeFile
end

local function init()
    system.registerTheme({
        key = "Summit",
        name = "Summit",
        roundButtons = false,
        focusStyle = "outline",
        colors = {
            lcd.RGB(0xF4, 0xF6, 0xFA), -- PRIMARY_COLOR
            lcd.RGB(0x37, 0x34, 0x2F), -- SECONDARY_BGCOLOR
            lcd.RGB(0xE8, 0xA3, 0x3D), -- HIGHLIGHT_COLOR
            lcd.RGB(0x0C, 0x0C, 0x10), -- HIGHLIGHT_CONTRASTING_COLOR
            lcd.RGB(0x69, 0x67, 0x65), -- DISABLE_COLOR
            lcd.RGB(0x22, 0x1E, 0x18), -- PRIMARY_BGCOLOR
            COLOR_BLACK, -- OVERLAY_COLOR
            lcd.RGB(0xEF, 0xD1, 0xA5), -- SECONDARY_COLOR
            lcd.RGB(0x48, 0xE2, 0x8A), -- SAFE_COLOR
            lcd.RGB(0x0E, 0x0D, 0x0B), -- PAGE_BGCOLOR
            lcd.RGB(0xFF, 0x52, 0x5C), -- ERROR_COLOR
            lcd.RGB(0xFF, 0xD0, 0x8A), -- ACTIVE_COLOR
            lcd.RGB(0x7A, 0x79, 0x77), -- INACTIVE_COLOR
            lcd.RGB(0xFE, 0xD4, 0x95), -- BUTTON_BORDER_ACTIVE_COLOR
            lcd.RGB(0x50, 0x4E, 0x4A), -- BUTTON_BORDER_COLOR
            lcd.RGB(0xFF, 0xC7, 0x48), -- WARNING_COLOR
            lcd.RGB(0x06, 0x16, 0x0B), -- SAFE_CONTRASTING_COLOR
            lcd.RGB(0x0E, 0x0D, 0x0B), -- TOPLCD_BGCOLOR
        },
        toolbarBackground = lcd.loadBitmap(selectToolbar("toolbar-summit.png", "toolbar-summit-x18.png")),
    })
end

return { init = init }
