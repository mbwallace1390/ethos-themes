# RF Teal Pro v1.2.5

## Preview before installing

After extracting the ZIP on your computer, open [preview.png](preview.png) to see this theme's colors and artwork. The control layout is illustrative, not a firmware screenshot.

ETHOS Suite installs only the runtime files and leaves this preview on your computer. For manual installation, you can omit `preview.png`.

Requires ETHOS 26.1.0 or newer; API checked against 26.1.2. Radio validation is still required.

Install the ZIP with ETHOS Suite's local ZIP installer. For manual ZIP installation, create `scripts/theme-rf-teal-pro/` on the transmitter and extract the ZIP contents into that folder.

A lightweight FrSky ETHOS theme based on the proven RF Blue Pro design.

- Bright teal outline focus
- Dark square controls
- Clear active, inactive, and disabled states
- Responsive 784x50 X20 / 464x50 X18 toolbar
- ETHOS-safe internal key `RFTeal`
- Installs beside every other RF Pro theme
- Palette-matched ETHOS header logo with a transparent background
- Continuous toolbar styling with prominent artwork arranged around the lettering at both native widths

To install from repository sources, copy the complete `theme-rf-teal-pro` folder into the transmitter's `scripts` folder, restart, and select **RF Teal Pro** under **System > General > Theme**.

`main.luac` is intentionally omitted so ETHOS creates a fresh compiled copy.
