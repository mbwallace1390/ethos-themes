# RF Blue Pro v1.0.0

RF Blue Pro is a lightweight FrSky ETHOS theme designed for Rotorflight RF Suite.

## Features

- Dark controls with bright cyan-blue outline focus
- Sharper square control styling
- Clearer active, inactive, and disabled states
- Lightweight 784x50 toolbar with a thin blue accent line
- Short internal theme key `RFPro`
- Installs beside RF Suite Blue without replacing it
- No distributed `main.luac`; ETHOS compiles a fresh copy

## Installation

1. Copy the complete `theme-rfblue-pro` folder into the transmitter's `scripts` folder.
2. Restart the transmitter.
3. Open **System > General > Theme**.
4. Select **RF Blue Pro**.
