# Deep Space v1.1.0

Requires ETHOS 26.1.0 or newer; API checked against 26.1.2. Radio validation is still required.

Install the ZIP with ETHOS Suite's local ZIP installer. For manual ZIP installation, create `scripts/theme-deep-space/` on the transmitter and extract the ZIP contents into that folder.

**Collection:** Cosmic

A standalone FrSky ETHOS radio theme with custom toolbar artwork.

- Focus: `outline`
- Controls: square
- Internal key: `DSpace`
- Responsive 784x50 X20 / 464x50 X18 toolbar
- Does not modify Rotorflight or RF Suite Lua files

To install from repository sources, copy `theme-deep-space` into the transmitter `scripts` folder, restart, then select **Deep Space** under **System > General > Theme**.
