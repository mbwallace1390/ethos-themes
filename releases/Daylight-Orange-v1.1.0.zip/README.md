# Daylight Orange v1.1.0

Requires ETHOS 26.1.0 or newer; API checked against 26.1.2. Radio validation is still required.

Install the ZIP with ETHOS Suite's local ZIP installer. For manual ZIP installation, create `scripts/theme-daylight-orange/` on the transmitter and extract the ZIP contents into that folder.

**Family:** Daylight

A lightweight standalone FrSky ETHOS theme.

- Focus: `invert`
- Controls: rounded
- Internal key: `DayOrg`
- Responsive 784x50 X20 / 464x50 X18 toolbar

To install from repository sources, copy `theme-daylight-orange` into the transmitter `scripts` folder, restart, and select **Daylight Orange**.
