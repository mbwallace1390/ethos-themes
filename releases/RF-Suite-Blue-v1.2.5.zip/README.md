# RF Suite Blue v1.2.5

## Preview before installing

After extracting the ZIP on your computer, open [preview.png](preview.png) to see this theme's colors and artwork. The control layout is illustrative, not a firmware screenshot.

ETHOS Suite installs only the runtime files and leaves this preview on your computer. For manual installation, you can omit `preview.png`.

Requires ETHOS 26.1.0 or newer; API checked against 26.1.2. Radio validation is still required.

Install the ZIP with ETHOS Suite's local ZIP installer. For manual ZIP installation, create `scripts/theme-rfsuite-blue/` on the transmitter and extract the ZIP contents into that folder.

A standalone dark FrSky ETHOS radio theme with rounded controls and solid blue selected controls.

## Changes in v1.2.4

- Clarifies the standalone installation and purpose.
- Preserves the palette, artwork, runtime behavior, and existing RF Suite Blue theme identity.

## Changes in v1.0.5

- Uses a thinner, sharper 784x50 toolbar gradient.
- Changes the outer page background to blue-black so ETHOS's fixed side margins blend into the theme instead of appearing gray.
- Keeps the proven six-character internal theme key `RFBlue`.
- Keeps the 784-pixel toolbar width because testing confirmed ETHOS enforces that toolbar safe area even when an 800-pixel image is supplied.
- Omits `main.luac` so ETHOS compiles a fresh copy during startup.

- Palette-matched ETHOS header logo with a transparent background
- Continuous toolbar styling with the accent band below the lettering at both native widths

## Installation

1. Delete any existing `scripts/theme-rfsuite-blue` folder.
2. Restart the transmitter.
3. Install the release ZIP through ETHOS Suite, or create `scripts/theme-rfsuite-blue/` and extract the ZIP contents there. To install from repository sources, copy the complete `theme-rfsuite-blue` folder into `scripts`.
4. Restart the transmitter again.
5. Select **RF Suite Blue** under **System > General > Theme**.

- Automatically selects 784x50 artwork on 800px radios and 464x50 artwork on standard X18 radios
