-- Pink Hope
-- Standalone ETHOS cancer-awareness radio theme.
-- Rotorflight and RF Suite files are not modified.
local function selectToolbar(largeFile, smallFile)
    local version = system.getVersion()
    if version and type(version.lcdWidth) == "number" and version.lcdWidth <= 480 then
        return smallFile
    end
    return largeFile
end

local function loadToolbar(largeFile, smallFile)
    -- Optional artwork must not prevent registration when it cannot be loaded.
    local ok, bitmap = pcall(lcd.loadBitmap, selectToolbar(largeFile, smallFile))
    if ok and bitmap then
        return bitmap
    end
    return nil
end

local function init()
    -- Skip unsupported firmware before creating colors or loading artwork.
    if type(system.registerTheme) ~= "function" then return end
    -- Load the optional palette-matched logo once; failures keep the theme usable.
    local logoOk, toolbarLogo = pcall(lcd.loadBitmap, "logo-pink-hope.png")
    if not logoOk then toolbarLogo = nil end
    system.registerTheme({
        key = "PinkHp",
        name = "Pink Hope",
        roundButtons = false,
        focusStyle = "outline",
        colors = {
            lcd.RGB(0xF5, 0xF7, 0xFA), -- PRIMARY_COLOR
            lcd.RGB(0x4A, 0x25, 0x35), -- SECONDARY_BGCOLOR
            lcd.RGB(0xF4, 0x8F, 0xB1), -- HIGHLIGHT_COLOR
            lcd.RGB(0x0C, 0x0A, 0x0D), -- HIGHLIGHT_CONTRASTING_COLOR
            lcd.RGB(0x84, 0x75, 0x7D), -- DISABLE_COLOR
            lcd.RGB(0x32, 0x18, 0x24), -- PRIMARY_BGCOLOR
            COLOR_BLACK, -- OVERLAY_COLOR
            lcd.RGB(0xF5, 0xC8, 0xD9), -- SECONDARY_COLOR
            lcd.RGB(0x56, 0xE2, 0x89), -- SAFE_COLOR
            lcd.RGB(0x1A, 0x0E, 0x15), -- PAGE_BGCOLOR
            lcd.RGB(0xFF, 0x4E, 0x58), -- ERROR_COLOR
            lcd.RGB(0xFF, 0xD1, 0xE1), -- ACTIVE_COLOR
            lcd.RGB(0xA0, 0x95, 0x9B), -- INACTIVE_COLOR
            lcd.RGB(0xFF, 0xD1, 0xE1), -- BUTTON_BORDER_ACTIVE_COLOR
            lcd.RGB(0x7B, 0x40, 0x58), -- BUTTON_BORDER_COLOR
            lcd.RGB(0xFF, 0xC7, 0x48), -- WARNING_COLOR
            lcd.RGB(0x07, 0x18, 0x0C), -- SAFE_CONTRASTING_COLOR
            lcd.RGB(0x1A, 0x0E, 0x15), -- TOPLCD_BGCOLOR
        },
        toolbarLogo = toolbarLogo,
        toolbarBackground = loadToolbar("toolbar-pink-hope.png", "toolbar-pink-hope-x18.png"),
    })
end

return { init = init }
