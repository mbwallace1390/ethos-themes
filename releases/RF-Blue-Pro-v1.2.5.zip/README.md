# RF Blue Pro v1.2.5

## Preview before installing

After extracting the ZIP on your computer, open [preview.png](preview.png) to see this theme's colors and artwork. The control layout is illustrative, not a firmware screenshot.

ETHOS Suite installs only the runtime files and leaves this preview on your computer. For manual installation, you can omit `preview.png`.

Requires ETHOS 26.1.0 or newer; API checked against 26.1.2. Radio validation is still required.

Install the ZIP with ETHOS Suite's local ZIP installer. For manual ZIP installation, create `scripts/theme-rfblue-pro/` on the transmitter and extract the ZIP contents into that folder.

RF Blue Pro is a standalone FrSky ETHOS radio theme with cyan-blue accents and square controls.

Version 1.2.4 clarifies the standalone installation and purpose. Its palette, artwork, theme identity, and runtime behavior are unchanged.

Features:
- Bright cyan-blue outline focus
- Sharper square controls
- Clear active, inactive, and disabled states
- Responsive 784x50 X20 / 464x50 X18 toolbar
- Internal theme key RFPro
- Palette-matched ETHOS header logo with a transparent background
- Continuous toolbar styling with the accent band below the lettering at both native widths

To install from repository sources, copy the complete theme-rfblue-pro folder into the transmitter scripts folder, restart, and select RF Blue Pro under System > General > Theme.

main.luac is intentionally omitted so ETHOS creates a fresh copy.
