# RF Suite Blue for ETHOS

This build uses the short internal theme key `RFBlue`.

FrSky's official themes keep the internal `system.registerTheme()` key to
seven characters or fewer. The visible theme name remains **RF Suite Blue**.

## Clean install

1. Delete the complete `scripts/theme-rfsuite-blue` folder from the radio.
2. Restart the radio once.
3. Install this ZIP with ETHOS Suite, or copy the included
   `theme-rfsuite-blue` folder into `scripts`.
4. Restart the radio.
5. Select **RF Suite Blue** under System > General > Theme.

`main.luac` is intentionally omitted. ETHOS will compile a new one from the
corrected `main.lua` during startup.
